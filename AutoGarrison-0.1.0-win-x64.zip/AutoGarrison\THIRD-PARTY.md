# Harmony

Uses [Harmony](https://github.com/pardeike/Harmony), version 2.3.3, MIT license.

The bundled runtime DLL is the `lib/net472/0Harmony.dll` entry from the official
[Lib.Harmony 2.3.3 NuGet package](https://www.nuget.org/packages/Lib.Harmony/2.3.3).

Upstream license is preserved in `lib/Harmony-LICENSE.txt`.

STAB informed the choice of AppDomainManager as a compatible game startup hook.
This prototype contains its own bootstrap and does not require STAB installation.
